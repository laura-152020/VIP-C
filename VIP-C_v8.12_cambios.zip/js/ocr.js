/* VIP-C — Lectura del sello de la foto en el navegador (sin servidor).
 * 1) Recorta la franja inferior de la foto (donde va el sello), la amplía y aísla el texto blanco.
 * 2) Lee el texto con Tesseract (español).
 * 3) Interpreta fecha, coordenadas, nombre del tramo y código de vía con reglas tolerantes a errores de OCR.
 */
const LectorSello = (function () {
  "use strict";

  const RUTAS = {
    workerPath: "https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/dist/worker.min.js",
    corePath: "https://cdn.jsdelivr.net/npm/tesseract.js-core@6.0.0",
    langPath: "https://cdn.jsdelivr.net/npm/@tesseract.js-data/spa@1.0.0/4.0.0_best_int"
  };
  let trabajador = null;

  async function iniciar() {
    if (trabajador) return trabajador;
    if (!window.Tesseract) throw new Error("No cargó el lector de texto. Revisa la conexión y recarga la página.");
    trabajador = Tesseract.createWorker("spa", 1, RUTAS).then(async (w) => {
      await w.setParameters({ tessedit_pageseg_mode: "6", preserve_interword_spaces: "1" });
      return w;
    }).catch((e) => { trabajador = null; throw e; });
    return trabajador;
  }

  /* ---------- Preprocesamiento ---------- */
  function cargarImagen(src) {
    return new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => mal(new Error("No se pudo abrir la imagen.")); i.src = src; });
  }

  // modo "blanco": texto blanco → negro sobre blanco.
  // modo "sombra": igual, pero solo conserva blancos que tienen una sombra oscura cerca (descarta cielo y fondos claros).
  // modo "gris": escala de grises invertida con contraste.
  function franja(img, desdeY, hastaY, modo, umbral, desdeX) {
    umbral = umbral || 185; desdeX = desdeX || 0;
    const sw = img.naturalWidth || img.width, sh = img.naturalHeight || img.height;
    const y0 = Math.round(sh * desdeY), alto = Math.round(sh * (hastaY - desdeY));
    const x0 = Math.round(sw * desdeX), ancho = sw - x0;
    const escala = Math.min(sw < 900 ? 4 : 3, Math.max(1, 2200 / sw)); // fotos pequeñas (ej. dentro de un PDF): más ampliación
    const c = document.createElement("canvas");
    c.width = Math.round(ancho * escala); c.height = Math.round(alto * escala);
    const ctx = c.getContext("2d", { willReadFrequently: true });
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(img, x0, y0, ancho, alto, 0, 0, c.width, c.height);
    const d = ctx.getImageData(0, 0, c.width, c.height), p = d.data;
    for (let i = 0; i < p.length; i += 4) {
      const r = p[i], g = p[i + 1], b = p[i + 2];
      const mn = Math.min(r, g, b), mx = Math.max(r, g, b);
      let v;
      if (modo === "blanco" || modo === "sombra") v = (mn > umbral && mx - mn < 60) ? 0 : 255;
      else if (modo === "adapt" || modo === "local") v = (mx - mn < (modo === "local" ? 80 : 60)) ? mn : 0; // colores saturados nunca son texto; se resuelve abajo
      else { const l = 0.299 * r + 0.587 * g + 0.114 * b; v = Math.max(0, Math.min(255, (255 - l - 60) * 1.6 + 128)); }
      p[i] = p[i + 1] = p[i + 2] = v; p[i + 3] = 255;
    }
    if (modo === "sombra") filtrarPorSombra(d, c.width, c.height, Math.max(4, Math.round(c.height * 0.012)), img, x0, y0, escala);
    if (modo === "adapt") umbralAdaptativo(d, c.width, c.height, 40, 45);
    if (modo === "local") umbralAdaptativo(d, c.width, c.height, 30, 28, 110); // texto gris claro sobre asfalto
    ctx.putImageData(d, 0, 0);
    return c;
  }

  // Umbral según el fondo local: texto = más claro que el promedio de su entorno + margen (sirve en carretera clara y en vegetación)
  function umbralAdaptativo(d, w, h, r, margen, piso) {
    piso = piso || 185;
    const p = d.data, n = w * h, mn = new Float32Array(n);
    for (let j = 0, i = 0; j < n; j++, i += 4) mn[j] = p[i];
    // los valores ya son el mínimo de canal; saturación se revisa abajo con la imagen original no disponible, así que se usa solo brillo
    const I = new Float64Array((w + 1) * (h + 1));
    for (let y = 0; y < h; y++) { let fila = 0; for (let x = 0; x < w; x++) { fila += mn[y * w + x]; I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + fila; } }
    for (let y = 0; y < h; y++) {
      const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
      for (let x = 0; x < w; x++) {
        const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
        const suma = I[y1 * (w + 1) + x1] - I[y0 * (w + 1) + x1] - I[y1 * (w + 1) + x0] + I[y0 * (w + 1) + x0];
        const fondo = suma / ((y1 - y0) * (x1 - x0));
        const u = Math.min(240, Math.max(piso, fondo + margen));
        const j = y * w + x, v = mn[j] > u ? 0 : 255, i = j * 4;
        p[i] = p[i + 1] = p[i + 2] = v;
      }
    }
  }

  // Mínimo de luminancia en una ventana (2 pasadas separables) para saber si cada píxel tiene sombra cerca.
  function filtrarPorSombra(d, w, h, r, img, x0, y0, escala) {
    const cv = document.createElement("canvas"); cv.width = w; cv.height = h;
    const cx = cv.getContext("2d", { willReadFrequently: true });
    cx.drawImage(img, x0, y0, w / escala, h / escala, 0, 0, w, h);
    const o = cx.getImageData(0, 0, w, h).data;
    const lum = new Uint8Array(w * h);
    for (let i = 0, j = 0; j < lum.length; i += 4, j++) lum[j] = (o[i] * 299 + o[i + 1] * 587 + o[i + 2] * 114) / 1000;
    const tmp = new Uint8Array(w * h), mn = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let m = 255; for (let k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) { const v = lum[y * w + k]; if (v < m) m = v; }
      tmp[y * w + x] = m;
    }
    for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) {
      let m = 255; for (let k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) { const v = tmp[k * w + x]; if (v < m) m = v; }
      mn[y * w + x] = m;
    }
    const p = d.data;
    for (let j = 0, i = 0; j < mn.length; j++, i += 4) if (p[i] === 0 && mn[j] > 120) p[i] = p[i + 1] = p[i + 2] = 255;
  }


  // Separa un recorte (texto negro sobre blanco) en líneas de texto; cada línea se lee sola (psm 7), lo que evita que el OCR mezcle renglones.
  function lineasDe(c) {
    const w = c.width, h = c.height, d = c.getContext("2d", { willReadFrequently: true }).getImageData(0, 0, w, h).data;
    const fila = new Uint32Array(h);
    for (let y = 0; y < h; y++) { let n = 0; for (let x = 0; x < w; x += 2) if (d[(y * w + x) * 4] < 128) n++; fila[y] = n; }
    const minN = Math.max(3, w * 0.004), bandas = []; let ini = -1, hueco = 0;
    const tolera = Math.max(4, Math.round(h * 0.012));
    for (let y = 0; y < h; y++) {
      if (fila[y] >= minN) { if (ini < 0) ini = y; hueco = 0; }
      else if (ini >= 0 && ++hueco > tolera) { bandas.push([ini, y - hueco]); ini = -1; hueco = 0; }
    }
    if (ini >= 0) bandas.push([ini, h - 1]);
    const out = [];
    for (const [a, b] of bandas) {
      const alto = b - a + 1; if (alto < 14 || alto > h * 0.5) continue;
      const pad = Math.round(alto * 0.4), o = document.createElement("canvas");
      o.width = w + 2 * pad; o.height = alto + 2 * pad;
      const x = o.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, o.width, o.height);
      x.drawImage(c, 0, a, w, alto, pad, pad, w, alto); out.push(o);
    }
    return out.slice(0, 8);
  }

  /* ---------- Interpretación ---------- */
  const MESES = { ene: 1, feb: 2, mar: 3, abr: 4, may: 5, jun: 6, jul: 7, ago: 8, sep: 9, set: 9, oct: 10, nov: 11, dic: 12,
    jan: 1, apr: 4, aug: 8, dec: 12 };
  const ANT = { latMin: 5.3, latMax: 9.0, lonMin: 73.7, lonMax: 77.3 }; // lon en valor absoluto

  function sinTildes(s) { return s.normalize("NFD").replace(/[̀-ͯ]/g, ""); }

  function normalizar(t) {
    return String(t || "")
      .replace(/[“”″〃]/g, '"').replace(/[‘’′´`]/g, "'").replace(/''/g, '"')
      .replace(/[º˚°]/g, "°")
      .replace(/\r/g, "");
  }

  function fechaISO(a, m, d) {
    a = Number(a); m = Number(m); d = Number(d);
    if (a < 100) a += 2000;
    if (a < 2010 || a > 2040 || m < 1 || m > 12 || d < 1 || d > 31) return "";
    const f = new Date(Date.UTC(a, m - 1, d));
    if (f.getUTCMonth() !== m - 1) return "";
    return `${a}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  }

  function buscarFecha(texto) {
    const t = sinTildes(texto).toLowerCase().replace(/[|]/g, "1");
    // 9 de septiembre de 2026 · 9 sept. 2026 · 09-sep-2026
    let m = t.match(/(\d{1,2})\s*(?:de\s*|[-./\s])?\s*(ene|feb|mar|abr|may|jun|jul|ago|sep|set|oct|nov|dic|jan|apr|aug|dec)[a-z]*\.?\s*(?:de\s*|del\s*|[-./,\s])?\s*(\d{4})/);
    if (m) { const f = fechaISO(m[3], MESES[m[2]], m[1]); if (f) return { iso: f, texto: m[0] }; }
    // sept 9, 2026
    m = t.match(/(ene|feb|mar|abr|may|jun|jul|ago|sep|set|oct|nov|dic|jan|apr|aug|dec)[a-z]*\.?\s*(\d{1,2}),?\s*(\d{4})/);
    if (m) { const f = fechaISO(m[3], MESES[m[1]], m[2]); if (f) return { iso: f, texto: m[0] }; }
    // 2026-09-09 · 2026/09/09
    m = t.match(/(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})/);
    if (m) { const f = fechaISO(m[1], m[2], m[3]); if (f) return { iso: f, texto: m[0] }; }
    // 09/09/2026 · 9-9-26 (día/mes/año, formato Colombia)
    m = t.match(/(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})/);
    if (m) { const f = fechaISO(m[3], m[2], m[1]); if (f) return { iso: f, texto: m[0] }; }
    return null;
  }

  function enRango(lat, lon) {
    return lat != null && lon != null && Math.abs(lat) >= ANT.latMin && Math.abs(lat) <= ANT.latMax && Math.abs(lon) >= ANT.lonMin && Math.abs(lon) <= ANT.lonMax;
  }

  function dms(g, m, s) {
    g = Number(g); m = Number(m || 0); s = Number(String(s || 0).replace(",", "."));
    if (m >= 60 || s >= 60) return null;
    return g + m / 60 + s / 3600;
  }

  /* Coordenadas. El OCR suele perder o cambiar el símbolo de grados (6°10' → 610' · 75°9' → 75%9').
   * Se interpreta cada bloque numérico con las reglas de Antioquia: latitud 5–8° (1 dígito), longitud 73–77° (2 dígitos). */
  function resolverDMS(partes, gLen) {
    const out = [];
    const add = (g, m, s, incompleto) => {
      if (g === "" || m === "" || s === "" || g == null || m == null || s == null) return;
      // Segundos con el punto decimal perdido: 19544 → 19.544
      if (/^\d{3,}$/.test(String(s)) && Number(s) >= 60) s = String(s).slice(0, 2) + "." + String(s).slice(2);
      const v = dms(g, m, s); if (v != null) out.push({ v, g: Number(g), m: Number(m), s: String(Number(s)), incompleto: !!incompleto });
    };
    const sep = (x) => { const [a, b] = String(x).split("."); return [a, b ? "." + b : ""]; };
    if (partes.length >= 3) {
      add(partes[0], partes[1], partes[2]);
      if (partes[0].length > gLen) add(partes[0].slice(0, gLen), partes[1], partes[2]);
    }
    if (partes.length === 2) {
      const [a, b] = partes;
      if (a.length > gLen) { const m = a.slice(gLen); add(a.slice(0, gLen), m.length > 2 ? m.slice(-2) : m, b); }
      else {
        const [ib, dec] = sep(b);
        if (ib.length === 4) add(a, ib.slice(0, 2), ib.slice(2) + dec);
        if (ib.length === 3) { add(a, ib.slice(0, 1), ib.slice(1) + dec); add(a, ib.slice(0, 2), ib.slice(2) + dec); }
        if (ib.length <= 2) add(a, dec ? ib + dec : ib, "0", !dec); // minutos decimales, o segundos perdidos por el OCR
      }
    }
    if (partes.length === 1) {
      const [ib, dec] = sep(partes[0]);
      const g = ib.slice(0, gLen), r = ib.slice(gLen);
      for (const rr of (r.length >= 4 ? [r, r.slice(1)] : [r])) {
        if (rr.length === 4) add(g, rr.slice(0, 2), rr.slice(2) + dec);
        if (rr.length === 3) add(g, rr.slice(0, 1), rr.slice(1) + dec);
        if (rr.length === 2) add(g, rr.slice(0, 1), rr.slice(1) + dec, true); // ej. 7546 → 75°4'6" (dudoso: también podría ser 75°46')
      }
    }
    return out;
  }

  function leerBloque(bloque, tipo) {
    const partes = bloque.replace(/,/g, ".").split(/[^0-9.]+/).map((p) => p.replace(/^\.+|\.+$/g, "")).filter((p) => /\d/.test(p));
    if (!partes.length) return null;
    if (partes.length === 1 && /^\d{1,3}\.\d{3,}$/.test(partes[0])) { // grados decimales
      const v = Number(partes[0]);
      const ok = tipo === "lat" ? (v >= ANT.latMin && v <= ANT.latMax) : (v >= ANT.lonMin && v <= ANT.lonMax);
      if (ok) return { v, txt: String(v) };
    }
    const validos = resolverDMS(partes, tipo === "lat" ? 1 : 2)
      .filter((c) => tipo === "lat" ? (c.v >= ANT.latMin && c.v <= ANT.latMax) : (c.v >= ANT.lonMin && c.v <= ANT.lonMax));
    if (!validos.length) return null;
    const distintos = new Set(validos.map((c) => c.v.toFixed(5))).size;
    const c = validos[0];
    // dudoso: el OCR perdió separadores y hay más de una lectura posible (ej. 755947 = 75°59'47" o 75°9'47")
    return { v: c.v, txt: `${c.g}°${c.m}'${c.s}"${tipo === "lat" ? "N" : "W"}`, dudoso: distintos > 1 || c.incompleto };
  }

  function buscarCoordenadas(texto) {
    const r6 = (v) => Math.round(v * 1e6) / 1e6;
    const lineas = normalizar(texto).toUpperCase()
      .replace(/[%º˚*]/g, "°").replace(/\bV\s?W\b|\bVV\b|\bWV\b/g, "W")
      .split("\n");

    // 0) Hemisferio ANTES de los números: «N 6° 22' 10" W 75° 42' 28"» (sellos de varias apps de cámara)
    for (const l of [...lineas, lineas.join(" ")]) {
      const p = l.match(/(?:^|[^A-Z])([NS])\s*[:.,]?\s*([0-9][0-9°'". ,?%*!:;<\-]{2,24}?)\s*[,;]?\s*([WO])\s*[:.,]?\s*([0-9][0-9°'". ,?%*!:;<\-]{2,24})/);
      if (p) {
        const la = leerBloque(p[2], "lat"), lo = leerBloque(p[4], "lon");
        if (la && lo) return { lat: r6(la.v), lon: r6(-lo.v), latTxt: la.txt, lonTxt: lo.txt, dudoso: !!(la.dudoso || lo.dudoso) };
      }
    }

    // 1) Grados-minutos-segundos con hemisferio
    let lat = null, lon = null;
    for (const l of lineas) {
      const re = /([0-9][0-9°'". ,:;?%*!\-]{1,24}?)\s*([NSWO])(?![A-ZÁÉÍÓÚÑ])/g;
      let m;
      while ((m = re.exec(l))) {
        const tipo = (m[2] === "N" || m[2] === "S") ? "lat" : "lon";
        if ((tipo === "lat" && lat) || (tipo === "lon" && lon)) continue;
        const r = leerBloque(m[1], tipo);
        if (r) { if (tipo === "lat") lat = r; else lon = r; }
      }
      // Hemisferio perdido: busca el bloque que falta en la misma línea
      if (lat && !lon) { const b = l.match(/(7[3-7][0-9°'". :;]{3,20})/); if (b) lon = leerBloque(b[1], "lon"); }
      if (lon && !lat) { const b = l.match(/(?:^|[^0-9])([5-8][0-9°'". :;]{3,14})/); if (b) lat = leerBloque(b[1], "lat"); }
      if (lat && lon) return { lat: r6(lat.v), lon: r6(-lon.v), latTxt: lat.txt, lonTxt: lon.txt, dudoso: !!(lat.dudoso || lon.dudoso) };
    }

    // 2) Grados y minutos decimales: 6°10.700'N 75°9.950'W
    const t = lineas.join("\n");
    let m = t.match(/([5-8])\s*°\s*(\d{1,2}[.]\d+)'?\s*N[\s,;]+(7[3-7])\s*°\s*(\d{1,2}[.]\d+)'?\s*[WO]/);
    if (m) {
      const la = Number(m[1]) + Number(m[2]) / 60, lo = Number(m[3]) + Number(m[4]) / 60;
      if (Number(m[2]) < 60 && Number(m[4]) < 60) return { lat: r6(la), lon: r6(-lo), latTxt: m[1] + "°" + m[2] + "'N", lonTxt: m[3] + "°" + m[4] + "'W" };
    }

    // 3) Decimales: 6.178333, -75.165833 · LAT 6,1783 LON -75,1658 (el OCR a veces cambia el punto por guion)
    const reDec = /(-?[5-8])[.,](\d{3,8})[^0-9]{1,12}?(-?\s?7[3-7])[.,\-](\d{3,8})/g;
    while ((m = reDec.exec(t))) {
      const la = Number(m[1].replace(/\s/g, "") + "." + m[2]), lo = -Math.abs(Number(m[3].replace(/\s/g, "") + "." + m[4]));
      if (enRango(la, lo)) return { lat: r6(la), lon: r6(lo), latTxt: String(r6(la)), lonTxt: String(r6(lo)) };
    }
    return null;
  }

  // Código de vía departamental: 60AN17 · 60AN16-1 · 62AN09-2 (el OCR puede leer 0 como O)
  const RE_CODIGO = /\b(\d[0-9O]\s?[A-Z]{2}\s?[0-9O]{2}(?:\s?-\s?[0-9O]{1,2})?)(?![0-9A-Z])/i;
  const limpiarCodigo = (c) => { const x = c.toUpperCase().replace(/\s/g, ""); return x.slice(0, 2).replace(/O/g, "0") + x.slice(2, 4) + x.slice(4).replace(/O/g, "0"); };
  function buscarTramo(texto) {
    const lineas = normalizar(texto).split("\n").map((l) => l.trim()).filter(Boolean);
    let codigo = "";
    for (const l of lineas) { const c = l.match(RE_CODIGO); if (c) { codigo = limpiarCodigo(c[1]); break; } }
    for (const l of lineas) {
      const m = l.match(/^\W*v[ií1l]a[s]?\b\s*[:.\-]?\s*(.+)$/i);
      if (m && /[a-záéíóúñ]{3}/i.test(m[1])) return { tramo: limpiarTramo(m[1].replace(RE_CODIGO, "")), codigo };
    }
    // Tramo con varios segmentos: «Porcesito - La Cortada - Yolombó - Vegachí». Se toma el más completo,
    // aunque la línea traiga ruido con números al comienzo (ej. «7 Porcesito - …»).
    let cadena = "";
    for (const l of lineas) {
      const m = l.match(/[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ .]{2,}(?:\s*[-–—]\s*[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ .]{2,})+/);
      if (m) { const t = limpiarTramo(m[0]); if (calidadTramo(t) > calidadTramo(cadena)) cadena = t; }
    }
    if (cadena) return { tramo: cadena, codigo };
    // Respaldo: última línea con palabras (ej. "Grada el peñol"), sin fechas, coordenadas ni el logo
    const RUIDO = /secretar|infraestructura|emergencia|gobernaci|trabajamos|rentan|vial(es)?$|^\W*(antioquia|colombia)\W*$/i;
    for (let i = lineas.length - 1; i >= 0; i--) {
      const l = lineas[i];
      if (/\d/.test(l) || RUIDO.test(l)) continue;
      let toks = l.split(/\s+/);
      // Ruido a la izquierda del sello: se corta en el último símbolo suelto (">.", "|", "—"…), sin tocar el guion del tramo
      const ultimoSimbolo = toks.reduce((k, t, i) => (/^[^A-Za-zÁÉÍÓÚÑáéíóúñ0-9]+$/.test(t) && t !== "-" ? i : k), -1);
      if (ultimoSimbolo >= 0) toks = toks.slice(ultimoSimbolo + 1);
      while (toks.length && !/^[A-Za-zÁÉÍÓÚÑáéíóúñ]{3,}/.test(toks[0])) toks.shift();
      const t = limpiarTramo(toks.join(" "));
      if (calidadTramo(t) >= 2) return { tramo: t, codigo };
    }
    return { tramo: "", codigo };
  }

  // Busca nombres de municipios de Antioquia en el texto del sello (ej. "Grada el peñol" → El Peñol)
  function buscarMunicipio(texto) {
    if (typeof MUNICIPIOS === "undefined") return "";
    const t = " " + sinTildes(texto).toLowerCase().replace(/[^a-z0-9ñ ]+/g, " ").replace(/\s+/g, " ") + " ";
    let mejor = null, pos = Infinity;
    for (const m of MUNICIPIOS) {
      const nombres = [m.n, m.n.replace(/^(El|La) /, "")];
      for (const n of nombres) {
        const k = " " + sinTildes(n).toLowerCase() + " ";
        if (k.trim().length < 4) continue;
        const i = t.indexOf(k);
        if (i >= 0 && (i < pos || (i === pos && k.length > (mejor ? mejor.k.length : 0)))) { mejor = { m, k }; pos = i; }
      }
    }
    return mejor ? mejor.m.n : "";
  }
  // Calidad de un nombre de tramo: palabras reales (≥3 letras, con vocal) y pocos símbolos sueltos
  function calidadTramo(t) {
    if (!t) return 0;
    const letras = (t.match(/[A-Za-zÁÉÍÓÚÑáéíóúñ]/g) || []).length;
    if (letras / t.replace(/\s/g, "").length < 0.8) return 0;
    const palabras = t.split(/[\s-]+/).filter((w) => /^[A-Za-zÁÉÍÓÚÑáéíóúñ]{3,}$/.test(w) && /[aeiouáéíóú]/i.test(w));
    return palabras.length + (/ - /.test(t) ? 1 : 0) + (/[áéíóúñ]/i.test(t) ? 0.5 : 0);
  }
  function limpiarTramo(s) {
    const t = s.replace(/[|_~«»"]/g, "")
      .replace(/[.,;:]+\s*(?=[-–—])/g, " ")
      .replace(/\s*[-–—]+\s*/g, " - ")
      .replace(/(\s+[^\s]{1})+\s*$/, "")      // basura de 1 carácter al final (OCR)
      .replace(/^(?:[A-Z]{1,4}\s+)+(?:-\s+)?(?=[A-ZÁÉÍÓÚÑ][a-záéíóúñ])/, "") // basura en mayúsculas al comienzo (ej. «OST Porcesito», «ENS TEN BT - Remedios»)
      .replace(/\s{2,}/g, " ").replace(/[\s.,;:-]+$/, "").trim();
    return corregirSegmentos(t);
  }
  // Parecido entre dos textos (0 a 1), tolerante a errores de lectura: coeficiente de Dice sobre pares de letras
  function parecido(a, b) {
    const n = (x) => sinTildes(String(x || "")).toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
    const pares = (x) => { const r = new Map(); for (let i = 0; i < x.length - 1; i++) { const k = x.slice(i, i + 2); r.set(k, (r.get(k) || 0) + 1); } return r; };
    const A = pares(n(a)), B = pares(n(b));
    let inter = 0, ta = 0, tb = 0;
    A.forEach((v, k) => { ta += v; inter += Math.min(v, B.get(k) || 0); });
    B.forEach((v) => { tb += v; });
    return ta + tb ? (2 * inter) / (ta + tb) : 0;
  }
  // Corrige cada segmento del tramo con el nombre de municipio más parecido (ej. «Yolomboló» → «Yolombó», «Vegachi» → «Vegachí»)
  function corregirSegmentos(t) {
    if (typeof MUNICIPIOS === "undefined" || !t) return t;
    return t.split(" - ").map((seg) => {
      if (seg.length < 4) return seg;
      let mejor = null, p = 0;
      for (const m of MUNICIPIOS) { const x = parecido(seg, m.n); if (x > p) { p = x; mejor = m.n; } }
      return p >= 0.72 ? mejor : seg;
    }).join(" - ");
  }

  // Línea que solo dice el departamento o el país (sellos de apps de cámara): «Antioquia» · «Antioquia, Colombia» · «Colombia»
  const ES_REGION = /^\W*(?:(?:departamento\s+de\s+)?antioquia|colombia)(?:[\s,.\-–]+(?:antioquia|colombia))*\W*$/i;
  // En el formato de sello estándar, el tramo es la línea que va debajo de las coordenadas (puede ser una sola palabra, ej. «Remedios»)
  function tramoBajoCoordenadas(texto) {
    const lineas = normalizar(texto).split("\n").map((l) => l.trim()).filter(Boolean);
    // Línea de coordenadas: dos bloques de grados con N/S y W/O (el hemisferio puede ir antes o después)
    let k = -1;
    k = lineas.findIndex((l) => !!buscarCoordenadas(l)); // la primera línea donde se leen coordenadas completas
    if (k < 0 || k + 1 >= lineas.length) return "";
    if (/\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{1,2}:\d{2}/.test(lineas[k + 1])) return ""; // es la fecha, no el tramo
    // El tramo puede ocupar varias líneas (ej. «60AN16-1 - Granada - El Chocó - San» / «Carlos» / «PR 18+200»).
    // Algunas cámaras ponen primero el departamento o el país (ej. «Antioquia» / «Caicedo - Urrao»): esa línea no es el tramo.
    let t = lineas.slice(k + 1, k + 5).filter((l) => !/\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{1,2}:\d{2}/.test(l) && !ES_REGION.test(l)).slice(0, 3).join(" ");
    t = t.replace(/\b(?:pr|k|km|abs(?:cisa)?)\s*\.?\s*\d{1,3}\s*\+\s*\d{1,3}\b.*$/i, "")   // abscisa PR y lo que siga
      .replace(new RegExp(RE_CODIGO.source, "i"), " ")                                      // código de la vía (va en su propia casilla)
      .replace(/^[\s\-–—]+/, "");
    t = t.replace(/^[^A-Za-zÁÉÍÓÚÑáéíóúñ]+/, "").replace(/[^A-Za-zÁÉÍÓÚÑáéíóúñ.)]+$/, "");
    const toks = t.split(/\s+/);
    while (toks.length && !/^[A-ZÁÉÍÓÚÑ][a-záéíóúñ]/.test(toks[0])) toks.shift();       // ruido antes de la primera palabra con mayúscula
    t = limpiarTramo(toks.join(" "));
    const conector = /^(de|del|la|las|el|los|y)$/i, palabraNombre = (w) => /^[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}$/.test(w) || conector.test(w);
    if (/ - /.test(t)) {
      // Tramo con segmentos: desde el primer segmento con mayúscula hasta el final
      const m = t.match(/[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ .]{2,}(?:\s*-\s*[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ .]{2,})+$/);
      if (m) t = m[0].trim();
    } else if (typeof MUNICIPIOS !== "undefined") {
      // Una sola parte con ruido del fondo a la izquierda (ej. «Dolar NY E Remedios»): se deja el municipio del final.
      // Si todo son palabras de nombre (ej. «Granada San Carlos»), se deja completo.
      const w = t.split(/\s+/);
      for (let n = Math.min(4, w.length); n >= 1; n--) {
        const cola = w.slice(-n).join(" ");
        const m = MUNICIPIOS.find((x) => parecido(cola, x.n) >= 0.8);
        if (m) { if (n === w.length || !w.slice(0, -n).every(palabraNombre)) t = m.n; break; }
      }
    }
    const palabras = t.split(/[\s-]+/).filter((w) => /^[A-Za-zÁÉÍÓÚÑáéíóúñ]{3,}$/.test(w) && /[aeiouáéíóú]/i.test(w));
    return palabras.length && (t.match(/[A-Za-zÁÉÍÓÚÑáéíóúñ]/g) || []).length / t.replace(/[\s-]/g, "").length > 0.85 ? t : "";
  }

  /* Quita el ruido del fondo que el OCR pega al tramo (ej. «LÍA ya EAN A ANA Caicedo - Urrao» → «Caicedo - Urrao»).
     En un tramo con segmentos, el primero se recorta por la izquierda y el último por la derecha hasta palabras
     con forma de nombre (Mayúscula + minúsculas, o de/del/la…). Si no queda nada que parezca un nombre, devuelve ""
     y el tramo lo pone la vía más cercana de la red vial. */
  const CONECTOR = /^(de|del|la|las|el|los|y|e)$/i;
  const esNombre = (w) => /^\(?[A-ZÁÉÍÓÚÑ][a-záéíóúñü]{2,}\.?\)?$/.test(w) || CONECTOR.test(w) || /^\(.*|.*\)$/.test(w);
  function depurarTramo(t) {
    if (!t) return "";
    if (!/ - /.test(t)) {
      const w = t.trim().split(/\s+/);
      const buenas = w.filter((x) => esNombre(x) || /^[a-záéíóúñ]{4,}$/.test(x)).length;
      return w.length <= 6 && buenas / w.length >= 0.6 && w.some((x) => /^[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}/.test(x)) && !ES_REGION.test(t) ? t : "";
    }
    const segs = t.split(" - ").map((x) => x.trim().split(/\s+/).filter(Boolean));
    const n = segs.length;
    const limpio = segs.map((w, i) => {
      if (i === 0) { let k = w.length; while (k > 0 && esNombre(w[k - 1])) k--; w = w.slice(k); }   // izquierda
      if (i === n - 1) { let k = 0; while (k < w.length && esNombre(w[k])) k++; w = w.slice(0, k); } // derecha
      while (w.length && CONECTOR.test(w[0]) && !/^(la|el|los|las)$/i.test(w[0])) w.shift();
      while (w.length && CONECTOR.test(w[w.length - 1])) w.pop();
      return (i > 0 && i < n - 1 && !w.every(esNombre)) ? "" : w.join(" ");
    }).filter((x) => /[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}/.test(x));
    return limpio.length >= 2 || (limpio.length === 1 && n === 1) ? corregirSegmentos(limpio.join(" - ")) : (limpio.length === 1 && /^[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{3,}/.test(limpio[0]) ? corregirSegmentos(limpio[0]) : "");
  }

  function interpretar(texto) {
    const f = buscarFecha(texto), c = buscarCoordenadas(texto), v = buscarTramo(texto);
    const bajo = c ? tramoBajoCoordenadas(texto) : "";
    if (bajo && !/^v[ií]a\b/i.test(v.tramo || "")) v.tramo = bajo; // en el formato estándar, la línea bajo las coordenadas manda
    v.tramo = depurarTramo(v.tramo);
    return {
      fecha: f ? f.iso : "", fechaTexto: f ? f.texto : "",
      latitud: c ? c.lat : null, longitud: c ? c.lon : null,
      latitudDMS: c ? c.latTxt : "", longitudDMS: c ? c.lonTxt : "", coordDudosa: !!(c && c.dudoso),
      tramo: v.tramo, codigoVia: v.codigo, municipioTexto: buscarMunicipio(texto)
    };
  }

  function puntaje(r) { return (r.latitud != null ? (r.coordDudosa ? 2 : 4) : 0) + (r.fecha ? 2 : 0) + (r.tramo ? 1 : 0); }

  /* ---------- Lectura completa ---------- */
  // opciones.rapido: para las fotos de un PDF; basta con leer las coordenadas y se prueban menos variantes
  async function leer(src, opciones) {
    const rapido = !!(opciones && opciones.rapido);
    const img = await cargarImagen(src);
    const w = await iniciar();
    // [desde, hasta, modo, umbral de blanco]. El primero sirve casi siempre; los demás cubren fondos claros, sellos más altos o arriba.
    // [desdeY, hastaY, modo, umbral, desdeX]. Los sellos de cámara suelen ir abajo a la derecha: primero esa zona (menos ruido), luego todo el ancho.
    // Formato de sello usado por todos (abajo a la derecha, texto blanco con sombra):
    //   «26/10/26, 10:36 a.m.» · «6° 38' 21.075" N, 74° 53' 24.732" W» · «Porcesito - La Cortada - Yolombó - Vegachí»
    // Primero se lee solo esa franja (más rápido y con menos ruido); si no basta, las pasadas generales.
    // Al final, los sellos que van ARRIBA a la derecha (varias apps de cámara) y el texto gris claro.
    const intentos = [[0.78, 1, "blanco", 225, 0.25], [0.78, 1, "sombra", 200, 0.25], [0.78, 1, "adapt", 0, 0.25], [0.75, 1, "blanco", 190, 0.2], [0.55, 1, "adapt", 0, 0.4], [0.55, 1, "blanco", 235, 0.4], [0.55, 1, "adapt"], [0.55, 1, "blanco", 200],
      [0, 0.3, "blanco", 225, 0.3], [0, 0.3, "sombra", 200, 0.3], [0, 0.3, "adapt", 0, 0.3], [0.55, 1, "sombra", 185], [0.72, 1, "blanco", 170, 0.3], [0.35, 1, "adapt"], [0.55, 1, "gris"], [0, 0.4, "adapt"]];
    let mejor = null, textos = [], textosN = 0;
    let tramoAncho = false; // el nombre del tramo leído en una pasada de ancho completo (no recortado a la izquierda)
    for (const [a, b, modo, umbral, x] of (rapido ? [intentos[0], intentos[1], intentos[3], intentos[2], intentos[8], intentos[9]] : intentos)) {
      const { data } = await w.recognize(franja(img, a, b, modo, umbral, x));
      textos.push(data.text);
      const r = interpretar(data.text);
      // Combina lo mejor de cada intento
      if (!mejor) { mejor = r; mejor.tramoConCoord = r.latitud != null && !!r.tramo; }
      else {
        if (r.latitud != null && (mejor.latitud == null || (mejor.coordDudosa && !r.coordDudosa)))
          Object.assign(mejor, { latitud: r.latitud, longitud: r.longitud, latitudDMS: r.latitudDMS, longitudDMS: r.longitudDMS, coordDudosa: r.coordDudosa });
        if (!mejor.fecha && r.fecha) Object.assign(mejor, { fecha: r.fecha, fechaTexto: r.fechaTexto });
        else if (r.fecha && r.fechaTexto && mejor.fechaTexto && r.fecha !== mejor.fecha && r.fechaTexto.replace(/\D/g, "").endsWith(mejor.fechaTexto.replace(/\D/g, "")) && r.fechaTexto.replace(/\D/g, "").length > mejor.fechaTexto.replace(/\D/g, "").length)
          Object.assign(mejor, { fecha: r.fecha, fechaTexto: r.fechaTexto }); // la otra pasada recortó el primer dígito
        const conCoord = r.latitud != null, mejorConCoord = !!mejor.tramoConCoord;
        if (r.tramo && (!mejor.tramo || (conCoord && !mejorConCoord) || (conCoord === mejorConCoord && (calidadTramo(r.tramo) > calidadTramo(mejor.tramo) || ((!x || x <= 0.25) && r.tramo.length > (mejor.tramo || "").length && calidadTramo(r.tramo) >= calidadTramo(mejor.tramo)))))) {
          mejor.tramo = r.tramo; mejor.tramoConCoord = conCoord;
        }
        if (!mejor.codigoVia && r.codigoVia) mejor.codigoVia = r.codigoVia;
        if (!mejor.municipioTexto && r.municipioTexto) mejor.municipioTexto = r.municipioTexto;
      }
      textosN = textos.length;
      if ((!x || x <= 0.25) && r.tramo) tramoAncho = true;
      if (puntaje(mejor) >= 7 && (tramoAncho || rapido)) break;
      if (rapido && mejor.latitud != null && !mejor.coordDudosa) break;
      if (textosN >= 3 && mejor.fecha && mejor.tramo && mejor.latitud == null) break; // sello sin coordenadas: no insistir
      if (textosN >= 4 && mejor.fecha && mejor.latitud != null) break;                 // lectura dudosa: no alargar más
    }
    if (mejor.latitud == null || !mejor.fecha) {
      // Último recurso: cada línea del sello se lee sola y, para los números, solo con dígitos y símbolos de coordenadas.
      try {
        const zonas = [[0.7, 1, "blanco", 215, 0.25], [0.7, 1, "blanco", 190, 0.25], [0.7, 1, "adapt", 0, 0.25], [0.7, 1, "local", 0, 0.25], [0.87, 1, "gris", 0, 0.72], [0.87, 1, "local", 0, 0.72], [0, 0.3, "blanco", 215, 0.3], [0, 0.1, "gris", 0, 0.45], [0, 0.1, "local", 0, 0.45], [0, 0.1, "sombra", 190, 0.45]];
        for (const [a, b, modo, umbral, x] of zonas) {
          const zona = franja(img, a, b, modo, umbral, x);
          const lin = lineasDe(zona); if (!lin.length || x >= 0.7) lin.push(zona); // zona angosta: también completa
          await w.setParameters({ tessedit_pageseg_mode: "7", tessedit_char_whitelist: "0123456789.,°'\" NSWO+-:/" });
          const nums = []; for (const l of lin) nums.push((await w.recognize(l)).data.text.trim());
          await w.setParameters({ tessedit_char_whitelist: "" });
          const letras = []; for (const l of lin) letras.push((await w.recognize(l)).data.text.trim());
          const tN = nums.join("\n"), tL = letras.join("\n");
          textos.push(tN, tL);
          const c = buscarCoordenadas(tN) || buscarCoordenadas(tL), f = buscarFecha(tL) || buscarFecha(tN);
          if (!mejor.fecha && f) Object.assign(mejor, { fecha: f.iso, fechaTexto: f.texto });
          if (c && mejor.latitud == null) Object.assign(mejor, { latitud: c.lat, longitud: c.lon, latitudDMS: c.latTxt, longitudDMS: c.lonTxt, coordDudosa: !!c.dudoso });
          if (!mejor.tramo) { const t = interpretar(tL).tramo; if (t) mejor.tramo = t; }
          if (mejor.latitud != null && mejor.fecha) break;
        }
      } catch (_) { /* sin la pasada por líneas */ }
      finally { try { await w.setParameters({ tessedit_pageseg_mode: "6", tessedit_char_whitelist: "" }); } catch (_) {} }
    }
    mejor.textoLeido = textos.join("\n---\n");
    mejor.selloLegible = mejor.latitud != null && !!mejor.fecha;
    return mejor;
  }

  return { leer, interpretar, iniciar, parecido, corregirTramo: corregirSegmentos, _franja: franja };
})();
